#!/bin/sh
rm reports/*.report
lua test.lua $*
